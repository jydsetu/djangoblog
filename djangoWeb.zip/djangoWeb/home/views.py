from django.shortcuts import render
from django.http import HttpResponse
from .models import *
# Create your views here.
def home(request):
	#return HttpResponse('<h1>Zahid is hasan</h1>')
	return render (request, "homepage.html")

def zahid(request):
	obj = Person.objects.all()
	#return HttpResponse('<h1>Zahid is hasan</h1>')
	return render (request, "index.html", {"obj":obj})
	